(function() {
const app = angular.module('Mail');
app.controller('composeCtrl' ['$scope', function($scope) {
$scope.mssg = "Inside compose";
}]);
})();
