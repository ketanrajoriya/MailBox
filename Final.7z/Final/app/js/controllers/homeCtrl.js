(function() {
var app = angular.module('Mail').controller('homeCtrl', function($scope) {
  $scope.mssg = "Inside home CTRL";
});
})();
