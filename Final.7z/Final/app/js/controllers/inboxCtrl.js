(function() {
const app = angular.module('Mail');
app.controller('inboxCtrl',['$scope', function($scope) {
$scope.mssg = "inside inbox ctrl";
}]);
})();
