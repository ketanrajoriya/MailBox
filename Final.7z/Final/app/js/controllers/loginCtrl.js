(function() {
var app = angular.module('Mail');
app.controller('loginCtrl', function($scope) {
$scope.user={};
$scope.formData = function(){
  console.log("user data"+JSON.stringify($scope.user));
$scope.user={};
}
})
})();
