(function() {
    'use strict'
     var app = angular.module('Mail',['ngMaterial', 'ngRoute']);
     app.config(['$routeProvider', function($routeProvider) {
       $routeProvider
       .when('/inbox',{
         templateUrl: 'js/views/inbox.html',
         controller: 'inboxCtrl'
       })
       .when('/compose', {
        tempelateUrl : 'js/views/compose.html',
        controller : 'composeCtrl'
       })
       .when('/home', {
         templateUrl :'js/views/home.html',
         controller : 'homeCtrl'
       })
       .when('/login', {
        templateUrl: 'js/views/login.html',
        controller : 'loginCtrl' 
       })
       .otherwise({redirectTo: '/login'});
}]);
})();
